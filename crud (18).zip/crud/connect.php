<?php


$conn=mysqli_connect('localhost','root','','crud');
if(!$conn){
    echo "connection refused";
}
?>